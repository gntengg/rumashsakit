# Healthcare-web-application
Web application for city hospital. Used languages Html, CSS, Bootstrap, JS, and PHP for backend 
